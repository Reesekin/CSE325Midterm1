import bpy
from .install_dependecies import *
from .import_anims import *
from .export_anims import *


# --- Blender Add On info
bl_info = {
    "name": "RedMod animations importer exporter",
    "blender": (2, 80, 0),
    "category": "Import-Export",
}


def menu_func_anims_import(self, context):
    self.layout.separator()
    self.layout.operator(import_anims.ImportAnims.bl_idname, text='Import .re animset file (.re)')

def menu_func_anims_export(self, context):
    self.layout.separator()
    self.layout.operator(export_anims.ExportAnims.bl_idname, text='Export animset as .re file (.re)')

# --- Register Blender Operator
def plugin_register():
    bpy.utils.register_class(import_anims.ImportAnims)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_anims_import)

    bpy.utils.register_class(export_anims.ExportAnims)
    bpy.types.OUTLINER_MT_object.append(menu_func_anims_export)
    bpy.types.OUTLINER_MT_context_menu.append(menu_func_anims_import)


# --- Unregister Blender Operator
def plugin_unregister():
    bpy.utils.unregister_class(import_anims.ImportAnims)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_anims_import)

    bpy.utils.unregister_class(export_anims.ExportAnims)
    bpy.types.OUTLINER_MT_object.remove(menu_func_anims_export)
    bpy.types.OUTLINER_MT_context_menu.remove(menu_func_anims_import)


def register():
    plugin_register()

def unregister():
    plugin_unregister()
