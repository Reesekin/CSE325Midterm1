import io, copy
import bpy, mathutils
from contextlib import redirect_stdout, redirect_stderr
from .import_anims import ImportAnims
from .asset_node import ReAssetNode


# --- Blender Operator
class ExportAnims(bpy.types.Operator):
    """Exports selected object as .re animset file"""
    bl_idname = "export_animset.re"
    bl_label = "Export .re animset"

    # ExportHelper mixin class uses this
    filename_ext = ".re"
    export_object = None

    filepath: bpy.props.StringProperty(
        name="File Path",
        description="Filepath used for exporting the file",
        maxlen=1024,
        subtype='FILE_PATH',
    )

    def execute(self, context):
        if not self.filepath:
            context.window_manager.fileselect_add(self)
            return {'RUNNING_MODAL'}

        self.export_object = context.object
        export_path = self.filepath
        self.filepath = ""

        anim_node = self.to_ReAnimNode()
        ImportAnims.hdf_manager.write_hdf_file(export_path, anim_node)

        return {'FINISHED'}

    def to_ReAnimNode(self, bones=None):
        asset_node = ReAssetNode()
        asset_node.asset_description.skeleton = ImportAnims.orig_skeleton #self.to_ReSkeletonNode()

        if not bones:
            bones = bpy.data.objects['Bones']

        self.parent_modifiers = {}
        self.parse_skeleton_for_exporting(asset_node, bones)

        if ImportAnims.calculate_with_matrix:
            return self.calculate_with_matrix(asset_node, bones)

        bpy.context.view_layer.objects.active = bones
        bpy.ops.object.mode_set(mode='OBJECT')
        scene = bpy.context.scene
        ob = bpy.context.object

        anim_clip = ImportAnims.orig_animation.animation_clip

        wm = bpy.context.window_manager
        wm.progress_begin(0, 100)

        # Cut keyframes if animation is shorter than the original
        for curve_name in anim_clip.get_curves_names():
            curve = anim_clip.get_animation_curve(curve_name)
            curve.keyframes_qts = curve.keyframes_qts[scene.frame_start:scene.frame_end]

        # Extend keyframes if animation is longer than the original
        for curve_name in anim_clip.get_curves_names():
            curve = anim_clip.get_animation_curve(curve_name)
            if len(curve.keyframes_qts) == 0:
                continue
            keyframes_qts = []
            for f in range(scene.frame_start, scene.frame_end):
                if f < len(curve.keyframes_qts):
                    keyframes_qts.append(curve.keyframes_qts[f])
                else:
                    keyframes_qts.append(copy.deepcopy(curve.keyframes_qts[-1]))
                if f not in ImportAnims.orig_poses:
                    ImportAnims.orig_poses[f] = ImportAnims.orig_poses[len(ImportAnims.orig_poses) - 1]
            curve.set_keyframes_qts(keyframes_qts)

        for f in range(scene.frame_start, scene.frame_end):
            wm.progress_update(int(100.0 * f / (scene.frame_end - scene.frame_start)))
            scene.frame_set(f)

            new_obj = bones.copy()
            new_obj.data = bones.data.copy()
            bpy.context.scene.collection.objects.link(new_obj)
            bpy.context.view_layer.objects.active = new_obj
            bpy.ops.object.mode_set(mode='POSE')
            output = io.StringIO()
            with redirect_stdout(output), redirect_stderr(output):
                bpy.ops.pose.armature_apply()
            bpy.ops.object.mode_set(mode='OBJECT')

            self.parse_bone_node_children(anim_clip, f, new_obj, asset_node.asset_description.skeleton.root)
            bpy.data.objects.remove(new_obj, do_unlink = True)

        wm.progress_end()

        asset_node.animation_container.add_animation(ImportAnims.orig_animation)
        return asset_node

    def parse_skeleton_for_exporting(self, asset_node, bones):
        def parse_children(node):
            for child in node.children:
                bone_name = child.name
                if bone_name in ImportAnims.orig_edit_bones:
                    ImportAnims.orig_edit_bones[bone_name]['orig_transform'] = child.transform
                parse_children(child)
        ImportAnims.orig_edit_bones['Root']['orig_transform'] = asset_node.asset_description.skeleton.root.transform
        parse_children(asset_node.asset_description.skeleton.root)

        bpy.context.view_layer.objects.active = bones
        bpy.ops.object.mode_set(mode='EDIT')
        self.parse_bone_node_children(None, None, bones, asset_node.asset_description.skeleton.root)

    def parse_bone_node_children(self, anim_clip, f, new_obj, nodes):
        for child_bone in nodes.children:
            curve_name = child_bone.name
            if anim_clip is not None:
                curve = anim_clip.get_animation_curve(curve_name)
                if curve == None:
                    continue
                if not (f < len(curve.keyframes_qts) and f in ImportAnims.orig_poses and curve_name in ImportAnims.orig_poses[f]):
                    continue
                orig_node_bone_transformation = curve.keyframes_qts[f].value
            else:
                if curve_name not in ImportAnims.orig_edit_bones:
                    continue
                orig_node_bone_transformation = ImportAnims.orig_edit_bones[curve_name]['orig_transform']
            orig_rot = orig_node_bone_transformation.rotation
            orig_rot = mathutils.Quaternion((orig_rot.w, orig_rot.x, orig_rot.y, orig_rot.z))
            # Rotations should be inverted for exporting from Blender
            orig_rot = orig_rot.inverted()

            if anim_clip is not None:
                orig_bone_transformation = ImportAnims.orig_poses[f][curve_name]['matrix_local'] #.edit_bones[curve_name].matrix
                new_bone_transformation = new_obj.data.bones[curve_name].matrix_local
            else:
                orig_bone_transformation = ImportAnims.orig_edit_bones[curve_name]['matrix']
                new_bone_transformation = new_obj.data.edit_bones[curve_name].matrix

            # Get the relative rotation between the newly positioned bone vector and the original (imported) bone vector
            delta_transformation = orig_bone_transformation @ new_bone_transformation.inverted()
            _, delta_rot, _ = delta_transformation.to_4x4().decompose()
            delta_rot = mathutils.Quaternion((delta_rot.w, delta_rot.x, delta_rot.y, delta_rot.z))
            # Save this relative rotation for later use
            self.parent_modifiers[curve_name] = delta_rot

            all_rotations = []
            all_modified_parent_rotations = mathutils.Quaternion((1, 0, 0, 0))
            def parse_parents(bone):
                if bone.parent:
                    if bone.parent.name == 'Root':
                        return
                    if anim_clip is not None:
                        _curve = anim_clip.get_animation_curve(bone.parent.name)
                        _orig_node_bone_transformation = _curve.keyframes_qts[f].value
                    else:
                        _orig_node_bone_transformation = ImportAnims.orig_edit_bones[bone.parent.name]['orig_transform']
                    _rot = _orig_node_bone_transformation.rotation
                    _rot = mathutils.Quaternion((_rot.w, _rot.x, _rot.y, _rot.z))
                    # Rotations should be inverted for Blender
                    _rot = _rot.inverted()
                    all_rotations.append(_rot)
                    all_modified_parent_rotations.rotate(self.parent_modifiers[bone.parent.name])
                    parse_parents(bone.parent)
            # Get all parent bones' rotations for the current bone
            parse_parents(new_obj.data.bones[curve_name])

            if new_obj.data.bones[curve_name].parent:
                if anim_clip is not None:
                    parent_curve = anim_clip.get_animation_curve(new_obj.data.bones[curve_name].parent.name)
                    parent_node_bone_transformation = parent_curve.keyframes_qts[f].value
                else:
                    parent_node_bone_transformation = ImportAnims.orig_edit_bones[new_obj.data.bones[curve_name].parent.name]['orig_transform']
                orig_parent_rot = parent_node_bone_transformation.rotation
                orig_parent_rot = mathutils.Quaternion((orig_parent_rot.w, orig_parent_rot.x, orig_parent_rot.y, orig_parent_rot.z))
                # Rotations should be inverted for Blender
                orig_parent_rot = orig_parent_rot.inverted()

                # Subtract the parents' relative rotations from current bone's rotation
                # (this way the parents' relative rotations will only be considered once)
                delta_rot.rotate(all_modified_parent_rotations.inverted())
                self.parent_modifiers[curve_name] = delta_rot

                # Calculate the current bone's rotation from the parents' rotations
                # (like in importing)
                _new_unit_vec = mathutils.Quaternion((1, 0, 0, 0))
                for curr_parent_rotation in all_rotations:
                    _new_unit_vec.rotate(curr_parent_rotation)
                # Add the current relative rotation
                _new_unit_vec.rotate(delta_rot.inverted())
                # Convert the relative rotation back for exporting
                for curr_parent_rotation in all_rotations[-1::-1]:
                    _new_unit_vec.rotate(curr_parent_rotation.inverted())

                # Add the relative rotation to the original rotation
                _new_unit_vec.rotate(orig_parent_rot)
                # Rotations should be inverted for exporting from Blender
                orig_parent_rot = _new_unit_vec.inverted()
                parent_rot = parent_node_bone_transformation.rotation
                if len(new_obj.data.bones[curve_name].parent.children) > 1:
                    # If the parent bone has multiple children, then the parent's rotation should not be modified
                    # Instead the current bone's vector should be updated
                    orig_pos = orig_node_bone_transformation.position

                    if anim_clip is not None:
                        new_bone_vec_tail = new_obj.data.bones[curve_name].tail_local
                        new_bone_vec_head = new_obj.data.bones[curve_name].head_local
                    else:
                        new_bone_vec_tail = new_obj.data.edit_bones[curve_name].tail
                        new_bone_vec_head = new_obj.data.edit_bones[curve_name].head
                    new_bone_vec_tail = mathutils.Vector((new_bone_vec_tail.x, new_bone_vec_tail.y, new_bone_vec_tail.z))
                    new_bone_vec_head = mathutils.Vector((new_bone_vec_head.x, new_bone_vec_head.y, new_bone_vec_head.z))
                    bone_vector = new_bone_vec_tail - new_bone_vec_head
                    _new_unit_vec = mathutils.Quaternion((1, 0, 0, 0))
                    for curr_parent_rotation in all_rotations:
                        _new_unit_vec.rotate(curr_parent_rotation)
                    # Considering the parents, rotate the vector back for exporing
                    bone_vector.rotate(_new_unit_vec.inverted())
                    orig_pos.x, orig_pos.y, orig_pos.z = bone_vector.x, bone_vector.y, bone_vector.z

                    # After updating the current bone's vector,
                    # its children should be rotated considering the new bone vector
                    orig_rot = orig_node_bone_transformation.rotation
                    orig_rot_quat = mathutils.Quaternion((orig_rot.w, orig_rot.x, orig_rot.y, orig_rot.z))
                    orig_rot_quat = orig_rot_quat.inverted()

                    # Same as before, but this time in order to rotate the child bone,
                    # the current bone's rotation should be added as well
                    _new_unit_vec = mathutils.Quaternion((1, 0, 0, 0))
                    all_rotations.insert(0, orig_rot_quat)
                    for curr_parent_rotation in all_rotations:
                        _new_unit_vec.rotate(curr_parent_rotation)
                    _new_unit_vec.rotate(delta_rot.inverted())
                    for curr_parent_rotation in all_rotations[-1::-1]:
                        _new_unit_vec.rotate(curr_parent_rotation.inverted())

                    _new_unit_vec.rotate(orig_rot_quat)
                    # Rotations should be inverted for exporting from Blender
                    orig_rot_quat = _new_unit_vec.inverted()
                    orig_rot.x, orig_rot.y, orig_rot.z, orig_rot.w = orig_rot_quat.x, orig_rot_quat.y, orig_rot_quat.z, orig_rot_quat.w
                else:
                    # If the parent bone has only one child (the current bone), then the parent's rotation should be modified
                    parent_rot.x, parent_rot.y, parent_rot.z, parent_rot.w = orig_parent_rot.x, orig_parent_rot.y, orig_parent_rot.z, orig_parent_rot.w

            self.parse_bone_node_children(anim_clip, f, new_obj, child_bone)

    def calculate_with_matrix(self, asset_node, bones):
        bpy.context.view_layer.objects.active = bones
        bpy.ops.object.mode_set(mode='OBJECT')
        scene = bpy.context.scene
        ob = bpy.context.object
        animation_keyframes = {}

        for f in range(scene.frame_start, scene.frame_end):
            scene.frame_set(f)

            new_obj = bones.copy()
            new_obj.data = bones.data.copy()
            bpy.context.scene.collection.objects.link(new_obj)
            bpy.context.view_layer.objects.active = new_obj
            bpy.ops.object.mode_set(mode='POSE')
            bpy.ops.pose.armature_apply()

            skeleton = self.to_ReSkeletonNode(new_obj)
            #skeleton = self.to_ReSkeletonNode(ImportAnims.orig_poses[f])
            if skeleton.root.name not in animation_keyframes:
                animation_keyframes[skeleton.root.name] = []
            animation_keyframes[skeleton.root.name].append(skeleton.root.transform)

            def parse_node_children(val):
                for child in val.get_children():
                    if child.name not in animation_keyframes:
                        animation_keyframes[child.name] = []
                    animation_keyframes[child.name].append(child.transform)
                    parse_node_children(child)
            parse_node_children(skeleton.root)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.data.objects.remove(new_obj, do_unlink = True)

        anim_node = ImportAnims.orig_animation #ReAnimationNode()
        for bone_name, animation_transforms in animation_keyframes.items():
            animation_curve_node = anim_node.animation_clip.get_animation_curve(bone_name)
            if not animation_curve_node:
                animation_curve_node = anim_node.animation_clip.add_animation_curve(bone_name)
            for idx, animation_transform in enumerate(animation_transforms):
                if idx < len(animation_curve_node.keyframes_qts):
                    animation_curve_node.keyframes_qts[idx].value = animation_transform
                else:
                    animation_curve_node.add_keyframe_qts(animation_transform, idx)
        asset_node.animation_container.add_animation(anim_node)

        return asset_node
