import h5py, math, mathutils, os, shutil
import numpy
from .asset_node import *


class HdfManager():
    def __init__(self):
        self.nodes = []

    def read_hdf_file(self, filename):
        self.input_filename = filename
        with h5py.File(filename, 'r') as fp:
            for key in fp.keys():
                if key == '.re_asset_node':
                    self.parse_re_asset_node(fp)

    def write_hdf_file(self, filename, anim_node):
        needs_to_be_moved = self.input_filename == filename
        if needs_to_be_moved:
            fname, ext = os.path.splitext(filename)
            filename = fname + '_' + ext
        with h5py.File(self.input_filename, 'r') as fp:
            with h5py.File(filename, 'w') as fw:
                for key in fp.keys():
                    fp.copy(fp[key], fw, key)
                re_skeleton_data = fw['.re_asset_node']['.re_asset_description_node']['.re_skeleton']
                skeleton_root = anim_node.asset_description.skeleton.root
                self.write_re_skeleton_node(skeleton_root, re_skeleton_data['Root'])
                re_anim_clip_data = fw['.re_asset_node']['.re_animation_container']['.re_animation']['.re_anim_clip']
                for key in re_anim_clip_data:
                    if isinstance(re_anim_clip_data[key], h5py.Group):
                        anim_curve = anim_node.animation_container.animations[0].animation_clip.get_animation_curve(key)
                        if anim_curve is not None:
                            keyframes_qts = anim_curve.keyframes_qts
                            if isinstance(keyframes_qts[0].value, ReTransform):
                                self.write_re_anim_node(keyframes_qts, re_anim_clip_data[key])
                            elif isinstance(keyframes_qts[0], ReKeyframe):
                                self.write_re_keyframe_node(keyframes_qts, re_anim_clip_data[key])
        if needs_to_be_moved:
            shutil.move(filename, self.input_filename)

    def get_nodes(self):
        return self.nodes

    def parse_re_asset_node(self, f):
        re_asset_node = ReAssetNode()
        re_skeleton_data = f['.re_asset_node']['.re_asset_description_node']['.re_skeleton']
        for key in re_skeleton_data:
            if isinstance(re_skeleton_data[key], h5py.Group):
                node_data = re_asset_node.asset_description.skeleton.root
                node_data.name = key
                node_data.transform = self.parse_transform_list(re_skeleton_data[key]['.transform'])
                for attr_data in re_skeleton_data[key]['.attributes']:
                    node_data.set_attr(attr_data[0].decode("utf-8"), attr_data[1])
                self.parse_re_group_node(re_skeleton_data[key], node_data)
        re_anim_clip_data = f['.re_asset_node']['.re_animation_container']['.re_animation']['.re_anim_clip']
        anim_clip = re_asset_node.animation_container.add_animation_clip()
        for key in re_anim_clip_data:
            if isinstance(re_anim_clip_data[key], h5py.Group):
                self.parse_re_anim_node(anim_clip, key, re_anim_clip_data[key])
        self.nodes.append(re_asset_node)

    def parse_re_group_node(self, re_skeleton_data, re_node_data):
        for key in re_skeleton_data:
            if isinstance(re_skeleton_data[key], h5py.Group):
                new_node_data = ReBoneNode()
                new_node_data.parent = re_node_data
                new_node_data.name = key
                new_node_data.transform = self.parse_transform_list(re_skeleton_data[key]['.transform'])
                re_node_data.children.append(new_node_data)
                self.parse_re_group_node(re_skeleton_data[key], new_node_data)

    def parse_re_anim_node(self, anim_clip, name, re_anim_node):
        if 'xformframes' in re_anim_node:
            anim_curve = anim_clip.add_curve(name)
            for line in re_anim_node['xformframes']:
                transform = ReTransform()
                transform.position = Position(line[0], line[1], line[2])
                transform.rotation = Quaternion(line[3], line[4], line[5], line[6])
                transform.scale = Scale(line[7], line[8], line[9])
                anim_curve.add_transformation(transform)
        if 'keyframes' in re_anim_node:
            anim_curve = anim_clip.add_curve(name)
            for line in re_anim_node['keyframes']:
                keyframe = ReKeyframe()
                keyframe.value = line[0]
                anim_curve.add_keyframe(keyframe)

    def write_re_skeleton_node(self, skeleton_root, re_skeleton_node):
        def parse_children(node, skeleton_node):
            for child in node.children:
                mat = self.re_transform_to_matrix(child.transform)
                re_skeleton_node_data = numpy.array([list(mat[0]) + list(mat[1]) + list(mat[2])])
                del skeleton_node[child.name]['.transform']
                skeleton_node[child.name].create_dataset('.transform', data=re_skeleton_node_data)
                skeleton_child_node = skeleton_node[child.name]
                parse_children(child, skeleton_child_node)
        parse_children(skeleton_root, re_skeleton_node)

    def write_re_anim_node(self, keyframes_qts, re_anim_node):
        time = 0.
        re_anim_node_data = []
        for keyframes_qt in keyframes_qts:
            re_transform = keyframes_qt.value
            pos, rot, scale = re_transform.position, re_transform.rotation, re_transform.scale 
            re_anim_node_data.append((
                pos.x, pos.y, pos.z,
                rot.x, rot.y, rot.z, rot.w,
                scale.x, scale.y, scale.z,
                time,
            ))
            time += 1.0
        headers = ['pos.x', 'pos.y', 'pos.z', 'rot.x', 'rot.y', 'rot.z', 'rot.w', 'scale.x', 'scale.y', 'scale.z', 'time']
        ds_dt = numpy.dtype({
            'names': headers,
            'formats': [('float32')]*len(headers),
        })
        re_anim_node_data = numpy.array(re_anim_node_data, dtype=ds_dt)
        del re_anim_node['xformframes']
        re_anim_node.create_dataset('xformframes', data=re_anim_node_data)

    def write_re_keyframe_node(self, keyframes_qts, re_anim_node):
        time = 0.
        re_keyframe_node_data = []
        for keyframes_qt in keyframes_qts:
            re_keyframe = keyframes_qt.value
            re_keyframe_node_data.append((
                re_keyframe,
                time,
            ))
            time += 1.0
        headers = ['value', 'time']
        ds_dt = numpy.dtype({
            'names': headers,
            'formats': [('float32')]*len(headers),
        })
        re_keyframe_node_data = numpy.array(re_keyframe_node_data, dtype=ds_dt)
        del re_anim_node['keyframes']
        re_anim_node.create_dataset('keyframes', data=re_keyframe_node_data)

    def parse_transform_list(self, float_list: h5py.Dataset) -> ReTransform:
        float_list = list(float_list[0])
        mtx = mathutils.Matrix([float_list[0:4], float_list[4:8], float_list[8:12], [0, 0, 0, 1]])
        transform = ReTransform()
        transform.scale, transform.rotation, transform.position = mtx.decompose()
        return transform

    def re_transform_to_matrix(self, transform):
        T = mathutils.Matrix.Translation(transform.scale)
        R = transform.rotation.to_matrix().to_4x4()
        S = mathutils.Matrix.Diagonal(transform.position.to_4d())
        M = T @ R @ S
        return M
