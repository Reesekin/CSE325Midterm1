import math, bpy, mathutils
from bpy.props import (StringProperty,)
from bpy_extras.io_utils import ImportHelper

from .asset_node import *
from .hdf_manager import HdfManager


class JointData:
    jox_rot = None
    joy_rot = None
    joz_rot = None
    bone_transforms = {}

class ImportAnims(bpy.types.Operator, ImportHelper):
    bl_idname = 'import_file.re'
    bl_label = 'Import Re anims file'

    filename_ext = '.re'
    filter_glob: StringProperty(
        default='*.re',
        options={'HIDDEN'},
    )

    calculate_with_matrix = False
    unit_vector = (0,1,0)
    compensation_matrix = mathutils.Matrix.Rotation(math.pi, 3, 'Z')
    orig_skeleton = {}
    orig_animation = {}
    orig_edit_bones = {}
    orig_poses = {}

    parent_rotations = {}
    parent_positions = {}

    hdf_manager = HdfManager()

    def execute(self, context):
        if not self.filepath:
            context.window_manager.fileselect_add(self)
            return {'RUNNING_MODAL'}

        if self.filepath is None or self.filepath == '':
            return {'CANCELLED'}

        ImportAnims.hdf_manager = HdfManager()
        ImportAnims.hdf_manager.read_hdf_file(self.filepath)
        self.filepath = ''

        nodes = ImportAnims.hdf_manager.get_nodes()
        self.import_anims(nodes)

        return {'FINISHED'}

    def import_anims(self, nodes):
        joint_data = JointData()
        joint_data.bone_transforms = {}
        for n in nodes:
            if isinstance(n, ReSkeletonNode):
                self.parse_skeleton_root(joint_data, n.root)
            if isinstance(n, ReAssetNode):
                wm = bpy.context.window_manager
                wm.progress_begin(0, 100)
                if hasattr(n, 'asset_description'):
                    skeleton = n.asset_description.skeleton
                    ImportAnims.orig_skeleton = skeleton
                    root = skeleton.root
                    bone_object = self.parse_skeleton_root(joint_data, root)

                    bpy.context.view_layer.update()
                    bpy.context.view_layer.objects.active = bone_object
                    bpy.ops.object.mode_set(mode='EDIT')
                    bones = {}
                    for bone in bone_object.data.edit_bones:
                        bones[bone.name] = {
                            'matrix': bone.matrix.copy(),
                            'tail': bone.tail,
                            'head': bone.head,
                        }
                    ImportAnims.orig_edit_bones = bones
                if hasattr(n, 'animation_container'):
                    anim_container = n.animation_container
                    for animation in anim_container.animations:
                        ImportAnims.orig_animation = animation
                        anim_clip = animation.animation_clip
                        for curve_name in anim_clip.get_curves_names():
                            curve = anim_clip.get_animation_curve(curve_name)
                            if curve_name in bone_object.pose.bones:
                                keyframes_len = len(curve.keyframes_qts)
                                bpy.context.scene.frame_start = 0
                                bpy.context.scene.frame_end = keyframes_len
                                break
                        for keyframe_idx in range(keyframes_len):
                            wm.progress_update(int(100.0 * keyframe_idx / keyframes_len))
                            bone_transformations = {}
                            for curve_name in anim_clip.get_curves_names():
                                if curve_name in bone_object.pose.bones:
                                    curve = anim_clip.get_animation_curve(curve_name)
                                    # Save original frame transformations
                                    bone_transformations[curve_name] = curve.keyframes_qts[keyframe_idx].value
                            # Get armature with pose
                            temp_bone_object = self.parse_skeleton_root(joint_data, root, bone_transformations)

                            # Apply pose in Blender
                            bpy.context.view_layer.update()
                            bpy.context.view_layer.objects.active = bone_object
                            bpy.ops.object.mode_set(mode='POSE')
                            self.add_constraints(bone_object, temp_bone_object)
                            self.apply_animation(keyframe_idx)
                            self.del_constraints()

                            # Save original pose transformations for exporting
                            bpy.context.view_layer.objects.active = temp_bone_object
                            bpy.ops.object.mode_set(mode='OBJECT')
                            bones = {}
                            for bone in temp_bone_object.data.bones:
                                bones[bone.name] = {
                                    'matrix': bone.matrix.copy(),
                                    'matrix_local': bone.matrix_local.copy(),
                                    'tail': bone.tail,
                                    'head': bone.head,
                                    'tail_local': bone.tail_local,
                                    'head_local': bone.head_local,
                                }
                            ImportAnims.orig_poses[keyframe_idx] = bones

                            bpy.data.objects.remove(temp_bone_object, do_unlink = True)
                            bpy.context.view_layer.objects.active = None
                        bpy.context.view_layer.update()
                        bpy.context.view_layer.objects.active = bone_object
                        bpy.ops.object.mode_set(mode='POSE')
                wm.progress_end()

    def parse_skeleton_root(self, joint_data, root, bone_transformations=None):
        pivot_bone = bpy.data.armatures.new('Armature')
        bone_object = bpy.data.objects.new('Bones', pivot_bone)
        bpy.context.scene.collection.objects.link(bone_object)
        bpy.context.view_layer.objects.active = bone_object
        bpy.ops.object.mode_set(mode='EDIT', toggle=False)
        joint_data.jox_rot = mathutils.Matrix.Rotation(root.get_attr('jointOrientX'), 4, 'X')
        joint_data.joy_rot = mathutils.Matrix.Rotation(root.get_attr('jointOrientY'), 4, 'Y')
        joint_data.joz_rot = mathutils.Matrix.Rotation(root.get_attr('jointOrientZ'), 4, 'Z')
        #bone_object.rotation_euler = mathutils.Euler((jox, joy, joz))
        root_bone = pivot_bone.edit_bones.new(root.name)
        root_bone.head = (0,0,0)
        root_bone.tail = ImportAnims.unit_vector
        #bone_object.rotation_euler.rotate(mathutils.Euler((0, 0, math.radians(180.0))))
        if bone_transformations:
            rot = bone_transformations['Root'].rotation
            rot = mathutils.Quaternion((rot.w, rot.x, rot.y, rot.z))
            ImportAnims.parent_rotations['Root'] = rot.inverted()
        self.get_bone_children(joint_data, pivot_bone, root, root_bone, bone_transformations)
        bpy.context.view_layer.update()
        for val in pivot_bone.edit_bones.values():
            val.use_connect = True
        '''for val in pivot_bone.edit_bones.values():
            val.roll = 0
            val.matrix.translation = val.tail'''
        bpy.context.view_layer.update()
        #self.hide_uninteresting_bones(pivot_bone.edit_bones.values())
        bpy.ops.object.mode_set(mode='POSE', toggle=False)
        #self.hide_uninteresting_bones(bone_object.data.bones.values())
        # The object needs to be rotated 180 deg around the Z axis to get the Blender's typical object rotation
        bpy.ops.object.mode_set(mode='OBJECT')
        bone_object.rotation_euler.rotate(ImportAnims.compensation_matrix)
        return bone_object

    def get_bone_children(self, joint_data, pivot_bone, parent_node, parent_bone=None, bone_transformations=None):
        jox_rot = joint_data.jox_rot
        joy_rot = joint_data.joy_rot
        joz_rot = joint_data.joz_rot
        #bone_transforms = joint_data.bone_transforms

        children = parent_node.get_children()
        for child in children:
            if not isinstance(child, ReBoneNode):
                continue
            bone = pivot_bone.edit_bones.new(child.name)

            # Start with unit vector
            bone.head = (0,0,0)
            bone.tail = ImportAnims.unit_vector

            transform = child.transform
            if bone_transformations and child.name in bone_transformations:
                transform = bone_transformations[child.name]

            rot = transform.rotation
            rot = mathutils.Quaternion((rot.w, rot.x, rot.y, rot.z))
            # Save current bone's rotation for later use, the rotation needs to be inverted for Blender
            ImportAnims.parent_rotations[child.name] = rot.inverted()

            pos = transform.position
            # Save current bone's position for later use
            ImportAnims.parent_positions[child.name] = pos

            if not ImportAnims.calculate_with_matrix:
                curr_parent_rotations = []

                def get_all_parent_rots(parent_bone):
                    if parent_bone.name not in ImportAnims.parent_rotations:
                        return
                    curr_parent_rotations.append(ImportAnims.parent_rotations[parent_bone.name])
                    if parent_bone.parent:
                        get_all_parent_rots(parent_bone.parent)
                get_all_parent_rots(parent_bone)

                bone.head = parent_bone.tail

                # New bone vectors are calculated like this:
                # - The current bone's vector should be rotated with
                # - all of it's parents'rotations in respective order
                # - (the current rotation is excluded)
                tail = mathutils.Vector((pos.x, pos.y, pos.z))
                all_rotation = mathutils.Quaternion((1, 0, 0, 0))
                for curr_parent_rotation in curr_parent_rotations:
                    all_rotation.rotate(curr_parent_rotation)
                tail.rotate(all_rotation)
                bone.tail = bone.head + tail
            else:
                mtx = self.from_re_transform_to_matrix(transform)
                mtx.transpose()
                mtx = parent_bone.matrix @ mtx
                bone.matrix = mtx

            bone.parent = parent_bone

            self.get_bone_children(joint_data, pivot_bone, child, bone, bone_transformations)

    def hide_uninteresting_bones(self, bones):
        for val in bones:
            if 'trajectory' in val.name.lower() or 'space' in val.name.lower() or 'ik' in val.name.lower() or 'weapon' in val.name.lower() or 'jnt' in val.name.lower() or 'vector' in val.name.lower() or 'camera' in val.name.lower() or 'gravity' in val.name.lower() or 'hips' in val.name.lower():
                val.hide = True

    def from_re_transform_to_matrix(self, transform):
        float_list = transform.to_float_list()
        mtx = mathutils.Matrix([float_list[0:4], float_list[4:8], float_list[8:12], float_list[12:16]])
        return mtx

    # add constrains and link them with target bones
    def add_constraints(self, source_ob, target_ob):        
        for bone in source_ob.pose.bones:
            sel_bone=source_ob.data.bones[bone.name]
            sel_bone.select=True
            bpy.context.object.data.bones.active=sel_bone

            trans_bone = bpy.context.object.pose.bones[bone.name]
            if trans_bone.constraints.find('Copy Transforms') == -1:
                if target_ob.pose.bones.get(bone.name) is not None:
                    bpy.ops.pose.constraint_add(type='COPY_TRANSFORMS')
                    trans_bone.constraints["Copy Transforms"].target = target_ob
                    trans_bone.constraints["Copy Transforms"].subtarget = bone.name

    # delete previously created constrains
    def del_constraints(self):
        for bone in bpy.context.selected_pose_bones:
            copyLocConstraints = [ c for c in bone.constraints if c.type == 'COPY_TRANSFORMS' ]
            # Iterate over all the bone's copy location constraints and delete them all
            for c in copyLocConstraints:
                bone.constraints.remove(c) # Remove constraint

    def apply_animation(self, frame_idx):
        # set keying set to whole character
        # we have all bones selected
        scene = bpy.context.scene
        scene.frame_current = frame_idx
        scene.frame_set(scene.frame_current)
        # apply visual transfrom to pose Ctrl+A
        bpy.ops.pose.visual_transform_apply()
        # insert all keyframes -> press I
        bpy.ops.anim.keyframe_insert(type = 'WholeCharacter')
