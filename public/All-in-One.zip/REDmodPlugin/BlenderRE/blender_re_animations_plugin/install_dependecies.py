def install_dependency(dependency_name):
    import subprocess
    import sys
    import os
    from pathlib import Path

    print(f'{dependency_name} package not found, installing...')
    py_exec = str(sys.executable)
    # Get lib directory
    lib = os.path.join(Path(py_exec).parent.parent, 'lib')
    # Ensure pip is installed
    subprocess.call([py_exec, '-m', 'ensurepip', '--user'])
    # Install packages
    proc = subprocess.Popen([py_exec, '-m', 'pip', 'install', f'--target={str(lib)}', dependency_name], stderr=subprocess.PIPE)
    _, error = proc.communicate()
    if len(error) > 0:
        raise PermissionError(f'{dependency_name} package installation failed! Please try to install the package manually into "{str(lib)}", or run Blender as an elevated user!')
    else:
        print(f'{dependency_name} package installed!')

try:
    import h5py
except ImportError:
    install_dependency('h5py')
