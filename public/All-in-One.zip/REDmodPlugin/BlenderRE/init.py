import math
 
def euler_from_quaternion(x, y, z, w):
    """
    Convert a quaternion into euler angles (roll, pitch, yaw)
    roll is rotation around x in radians (counterclockwise)
    pitch is rotation around y in radians (counterclockwise)
    yaw is rotation around z in radians (counterclockwise)
    """
    t0 = +2.0 * (w * x + y * z)
    t1 = +1.0 - 2.0 * (x * x + y * y)
    roll_x = math.atan2(t0, t1)

    t2 = +2.0 * (w * y - z * x)
    t2 = +1.0 if t2 > +1.0 else t2
    t2 = -1.0 if t2 < -1.0 else t2
    pitch_y = math.asin(t2)

    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (y * y + z * z)
    yaw_z = math.atan2(t3, t4)

    return Euler(roll_x, pitch_y, yaw_z) # in radians

class Position:
    def __repr__(self):
        return f"x: {self.x}, y: {self.y}, z: {self.z}"
    def __init__(self, x, y, z):
        self.x, self.y, self.z = x, y, z

class Quaternion:
    def __repr__(self):
        return f"x: {self.x}, y: {self.y}, z: {self.z}, w: {self.w}"
    def __init__(self, x, y, z, w):
        self.x, self.y, self.z, self.w = x, y, z, w

class Euler:
    def __repr__(self):
        return f"x: {self.x}, y: {self.y}, z: {self.z}"
    def __init__(self, x, y, z):
        self.x, self.y, self.z = x, y, z

class Rotation:
    def __repr__(self):
        return f"x: {self.euler.x}, y: {self.euler.y}, z: {self.euler.z}"
    def __init__(self, x, y, z, w):
        self.quaternion = Quaternion(x, y, z, w)
        self.euler = euler_from_quaternion(x, y, z, w)

class Scale:
    def __repr__(self):
        return f"x: {self.x}, y: {self.y}, z: {self.z}"
    def __init__(self):
        self.x, self.y, self.z = 1.0, 1.0, 1.0

class ReObject:
    def __repr__(self):
        return f"{self.name}"
    def __init__(self, name, pos, rot, scale=Scale(), parent=None):
        self.name, self.pos, self.rot, self.scale, self.parent = name, pos, rot, scale, parent


Hips = ReObject(
    name='Hips',
    pos=Position(4.715119361877441, 21.624122619628906, 90.43998718261719),
    rot=Rotation(0.7239086031913757, -0.10753875225782394, 0.6792252063751221, 0.05518050864338875),
)

LeftUpLeg = ReObject(
    name='LeftUpLeg',
    pos=Position(5.935103035881184e-05, -1.4993659533502068e-05, -8.298675537109375),
    rot=Rotation(0.0179501473903656, -0.20825335383415222, 0.969364583492279, 0.1289987564086914),
    parent=Hips,
)
LeftLeg = ReObject(
    name='LeftLeg',
    pos=Position(44.28732681274414, 0.0, 0.0),
    rot=Rotation(0.0, 0.0, 0.07997888326644897, 0.9967965483665466),
    parent=LeftUpLeg,
)
LeftFoot = ReObject(
    name='LeftFoot',
    pos=Position(42.51165771484375, 0.0, 0.0),
    rot=Rotation(-0.07608722150325775, -0.00021143197955098003, 0.23925454914569855, 0.9679710865020752),
    parent=LeftLeg,
)

RightUpLeg = ReObject(
    name='RightUpLeg',
    pos=Position(-5.935103035881184e-05, 1.4993659533502068e-05, 8.298675537109375),
    rot=Rotation(0.03966308757662773, -0.0735800564289093, 0.08797036856412888, 0.9926097393035889),
    parent=Hips,
)
RightLeg = ReObject(
    name='RightLeg',
    pos=Position(-44.28732681274414, 0.0, 0.0),
    rot=Rotation(0.0, 0.0, 0.344556987285614, 0.9387654066085815),
    parent=RightUpLeg,
)
RightFoot = ReObject(
    name='RightFoot',
    pos=Position(-42.51165771484375, 0.0, 0.0),
    rot=Rotation(-0.0244777612388134, 0.0531432218849659, 0.07423129677772522, 0.9955231547355652),
    parent=RightLeg,
)

Hips.children = [LeftUpLeg, RightUpLeg]
LeftUpLeg.children = [LeftLeg]
LeftLeg.children = [LeftFoot]
LeftFoot.children = []
RightUpLeg.children = [RightLeg]
RightLeg.children = [RightFoot]
RightFoot.children = []
